#!/usr/bin/env python3
"""
Kalshi BTC 15-minute signal watcher.
- Streams BTC/USDT 1-minute candles from Binance public market data.
- Polls Kalshi's public market API for the active KXBTC15M contract.
- Prints UP / DOWN / NO TRADE signals and logs predictions locally.
- SIGNALS ONLY: does not place orders or require API credentials.

This is an experimental indicator baseline, not a validated profitable strategy.
Verify Kalshi contract rules, settlement reference, and current API behavior before use.
"""

import json
import math
import os
import threading
import time
from collections import deque
from datetime import datetime, timezone
from urllib.parse import urlencode

import requests
import websocket

KALSHI_BASE = "https://api.elections.kalshi.com/trade-api/v2"
BINANCE_WS = "wss://stream.binance.com:9443/ws/btcusdt@kline_1m"
SERIES = "KXBTC15M"
POLL_SECONDS = 5
MIN_CANDLES = 20
LOG_FILE = "signals.csv"

lock = threading.Lock()
candles = deque(maxlen=300)
last_price = None
last_candle_time = None
ws_status = "starting"
kalshi_market = None
last_market_check = 0
session = requests.Session()
session.headers.update({"User-Agent": "btc-15m-signal-watcher/1.0"})


def utc_now():
    return datetime.now(timezone.utc)


def parse_dt(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def get_active_kalshi_market():
    """Find the nearest currently-open contract from the KXBTC15M series."""
    url = f"{KALSHI_BASE}/markets"
    params = {"series_ticker": SERIES, "status": "open", "limit": 200}
    response = session.get(url, params=params, timeout=8)
    response.raise_for_status()
    data = response.json()
    markets = data.get("markets", [])
    now = utc_now()
    eligible = []
    for market in markets:
        close_dt = parse_dt(market.get("close_time") or market.get("expiration_time"))
        if close_dt and close_dt > now:
            eligible.append((close_dt, market))
    if eligible:
        eligible.sort(key=lambda item: item[0])
        return eligible[0][1]
    # If API schema/market status differs, don't guess a contract.
    return None


def on_message(ws, message):
    global last_price, last_candle_time, ws_status
    try:
        payload = json.loads(message)
        k = payload.get("k", {})
        candle = {
            "time": int(k["t"]) // 1000,
            "open": float(k["o"]),
            "high": float(k["h"]),
            "low": float(k["l"]),
            "close": float(k["c"]),
            "volume": float(k["v"]),
            "closed": bool(k["x"]),
        }
        with lock:
            last_price = candle["close"]
            last_candle_time = candle["time"]
            # Replace current minute candle if the timestamp matches.
            if candles and candles[-1]["time"] == candle["time"]:
                candles[-1] = candle
            else:
                candles.append(candle)
            ws_status = "connected"
    except Exception as exc:
        print(f"\n[feed parse warning] {exc}")


def on_open(ws):
    global ws_status
    ws_status = "connected"


def on_error(ws, error):
    global ws_status
    ws_status = f"error: {error}"


def on_close(ws, code, msg):
    global ws_status
    ws_status = "disconnected"


def run_price_feed():
    while True:
        try:
            app = websocket.WebSocketApp(
                BINANCE_WS,
                on_open=on_open,
                on_message=on_message,
                on_error=on_error,
                on_close=on_close,
            )
            app.run_forever(ping_interval=20, ping_timeout=10)
        except Exception as exc:
            print(f"\n[feed reconnect] {exc}")
        time.sleep(3)


def ema(values, period):
    if len(values) < period:
        return None
    alpha = 2 / (period + 1)
    result = values[0]
    for value in values[1:]:
        result = alpha * value + (1 - alpha) * result
    return result


def rsi(values, period=14):
    if len(values) < period + 1:
        return None
    changes = [values[i] - values[i - 1] for i in range(1, len(values))]
    gains = sum(max(x, 0) for x in changes[-period:]) / period
    losses = sum(max(-x, 0) for x in changes[-period:]) / period
    if losses == 0:
        return 100.0 if gains > 0 else 50.0
    rs = gains / losses
    return 100 - (100 / (1 + rs))


def analyze(snapshot):
    """Simple, interpretable signal. Confidence is a score, NOT a calibrated probability."""
    closes = [c["close"] for c in snapshot]
    if len(closes) < MIN_CANDLES:
        return {"signal": "NO TRADE", "score": 0, "reason": f"Need {MIN_CANDLES} candles; have {len(closes)}"}

    fast = ema(closes[-40:], 5)
    slow = ema(closes[-60:], 13)
    momentum_1m = (closes[-1] / closes[-2] - 1) * 100 if closes[-2] else 0
    momentum_5m = (closes[-1] / closes[-6] - 1) * 100 if closes[-6] else 0
    strength = rsi(closes, 14)

    score = 0
    reasons = []
    if fast is not None and slow is not None:
        if fast > slow:
            score += 1
            reasons.append("fast EMA above slow EMA")
        elif fast < slow:
            score -= 1
            reasons.append("fast EMA below slow EMA")
    if momentum_1m > 0.015:
        score += 1
        reasons.append("positive 1m momentum")
    elif momentum_1m < -0.015:
        score -= 1
        reasons.append("negative 1m momentum")
    if momentum_5m > 0.04:
        score += 1
        reasons.append("positive 5m momentum")
    elif momentum_5m < -0.04:
        score -= 1
        reasons.append("negative 5m momentum")

    # Avoid chasing very extended RSI readings.
    if strength is not None:
        if strength >= 78 and score > 0:
            return {"signal": "NO TRADE", "score": score, "reason": f"RSI elevated ({strength:.1f}); avoid chasing"}
        if strength <= 22 and score < 0:
            return {"signal": "NO TRADE", "score": score, "reason": f"RSI depressed ({strength:.1f}); avoid chasing"}

    if score >= 2:
        signal = "UP"
    elif score <= -2:
        signal = "DOWN"
    else:
        signal = "NO TRADE"
    return {
        "signal": signal,
        "score": score,
        "reason": "; ".join(reasons) if reasons else "Indicators not aligned",
        "rsi": strength,
        "momentum_1m": momentum_1m,
        "momentum_5m": momentum_5m,
    }


def market_summary(market):
    if not market:
        return "Kalshi market: not found / not confirmed"
    title = market.get("title", "BTC 15-minute market")
    ticker = market.get("ticker", "unknown ticker")
    close_dt = parse_dt(market.get("close_time") or market.get("expiration_time"))
    remaining = max(0, int((close_dt - utc_now()).total_seconds())) if close_dt else None
    bid = market.get("yes_bid")
    ask = market.get("yes_ask")
    last = market.get("last_price")
    prices = []
    if bid is not None: prices.append(f"YES bid {bid}¢")
    if ask is not None: prices.append(f"YES ask {ask}¢")
    if last is not None: prices.append(f"last {last}¢")
    time_text = f"{remaining // 60}m {remaining % 60}s left" if remaining is not None else "time remaining unavailable"
    return f"Kalshi: {title} | {ticker} | {time_text} | " + (" / ".join(prices) if prices else "quote unavailable")


def log_signal(signal, price, market):
    new_file = not os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        if new_file:
            f.write("timestamp_utc,btc_price,signal,score,market_ticker,market_title,reason\n")
        fields = [
            utc_now().isoformat(), f"{price:.2f}", signal["signal"], str(signal["score"]),
            (market or {}).get("ticker", ""),
            (market or {}).get("title", "").replace(",", " "),
            signal.get("reason", "").replace(",", ";"),
        ]
        f.write(",".join(fields) + "\n")


def main():
    global kalshi_market, last_market_check
    print("Kalshi BTC 15-minute signal watcher — SIGNALS ONLY")
    print("Starting live BTC candle stream and Kalshi market lookup...")
    thread = threading.Thread(target=run_price_feed, daemon=True)
    thread.start()

    last_logged_key = None
    while True:
        now = time.time()
        if now - last_market_check >= 15:
            try:
                kalshi_market = get_active_kalshi_market()
            except Exception as exc:
                print(f"\n[Kalshi API warning] {exc}")
            last_market_check = now

        with lock:
            snapshot = list(candles)
            price = last_price
            candle_time = last_candle_time
            feed = ws_status

        os.system("cls" if os.name == "nt" else "clear")
        print("KALSHI BTC 15M — LIVE SIGNAL WATCHER")
        print("=" * 58)
        print(f"UTC time: {utc_now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"BTC feed: {feed}")
        print(f"BTC/USDT: ${price:,.2f}" if price is not None else "BTC/USDT: waiting for feed...")
        if candle_time:
            age = int(time.time() - candle_time)
            print(f"Latest candle update age: {age}s | candles cached: {len(snapshot)}")
        print("-" * 58)
        print(market_summary(kalshi_market))
        print("-" * 58)

        signal = analyze(snapshot)
        print(f"SIGNAL: {signal['signal']}")
        print(f"Indicator score: {signal['score']} (range -3 to +3; not a probability)")
        print(f"Reason: {signal['reason']}")
        if "rsi" in signal:
            print(f"RSI(14): {signal['rsi']:.1f} | 1m momentum: {signal['momentum_1m']:.3f}% | 5m momentum: {signal['momentum_5m']:.3f}%")

        stale = candle_time is None or (time.time() - candle_time > 90)
        if stale:
            print("\nWARNING: BTC data is stale; do not rely on this signal.")
        elif signal["signal"] != "NO TRADE":
            key = (candle_time, signal["signal"], (kalshi_market or {}).get("ticker"))
            if key != last_logged_key:
                log_signal(signal, price, kalshi_market)
                last_logged_key = key

        print("\nMode: signal-only; no orders are placed.")
        print("Log file: signals.csv")
        print("Ctrl+C to stop.")
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
